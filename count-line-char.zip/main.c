//write a c program to create a file and count the no. of lines and characters and print it. 
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
void main(){
    FILE *fp=NULL;
    char ch;
    int count=0,c=0;
    fp=fopen("content.txt","r");
    if(fp==NULL)
    {
        printf("error");
        exit(1);
        
    }
 while((ch=fgetc(fp))!=EOF)
 {
     if(ch=='\n')
     {count++;
     
 }
 else{
     c++;
 }
 }
 fclose(fp);
 printf("no. of lines %d",count);
 printf("\nno. of characters %d",c);
 
}